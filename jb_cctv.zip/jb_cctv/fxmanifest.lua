fx_version 'cerulean'
game 'gta5'

name 'jb_cctv'
author 'you'
description 'Reusable CCTV camera viewer with exports'
version '1.0.0'

ui_page 'html/index.html'        -- if you have an NUI for the overlay/time etc.

files {
    'html/index.html',
    'html/style.css',
    'html/app.js'
}

shared_scripts {
    '@qb-core/shared/locale.lua',
    'locales/en.lua',            -- your Lang:t() keys
    'config.lua'
}

client_scripts {
    'client/cameras.lua'
}

exports {
    'ViewCamera',
    'CloseCamera',
    'GetCameras',
    'SetCameraOnline',           -- toggle one or many
    'SetAllCamerasOnline'        -- quick all-on/all-off helpers
}