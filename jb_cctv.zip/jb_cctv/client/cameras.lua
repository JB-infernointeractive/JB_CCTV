-- client/cameras.lua
-- Ready-to-paste client for a reusable CCTV viewer.
-- ⚠️ Make sure your fxmanifest includes these client exports:
-- exports { 'ViewCamera', 'CloseCamera', 'GetCameras', 'SetCameraOnline', 'SetAllCamerasOnline' }

local QBCore = exports['qb-core']:GetCoreObject()

-- =========================
-- Config reference (expects Config.SecurityCameras in config.lua)
-- =========================

local currentCameraIndex = 0
local createdCamera = 0

-- ================
-- Utils
-- ================
local function GetCurrentTime()
    local hours = GetClockHours()
    local minutes = GetClockMinutes()
    if hours < 10 then
        hours = tostring(0 .. GetClockHours())
    end
    if minutes < 10 then
        minutes = tostring(0 .. GetClockMinutes())
    end
    return tostring(hours .. ':' .. minutes)
end

local function ChangeSecurityCamera(x, y, z, r)
    if createdCamera ~= 0 then
        DestroyCam(createdCamera, 0)
        createdCamera = 0
    end
    local cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', 1)
    SetCamCoord(cam, x, y, z)
    SetCamRot(cam, r.x, r.y, r.z, 2)
    RenderScriptCams(1, 0, 0, 1, 1)
    Wait(250)
    createdCamera = cam
end

local function CloseSecurityCamera()
    DestroyCam(createdCamera, 0)
    RenderScriptCams(0, 0, 1, 1, 1)
    createdCamera = 0
    ClearTimecycleModifier('scanline_cam_cheap')
    SetFocusEntity(GetPlayerPed(PlayerId()))
    if Config.SecurityCameras.hideradar then
        DisplayRadar(true)
    end
    FreezeEntityPosition(GetPlayerPed(PlayerId()), false)
end

local function InstructionButton(ControlButton)
    ScaleformMovieMethodAddParamPlayerNameString(ControlButton)
end

local function InstructionButtonMessage(text)
    BeginTextCommandScaleformString('STRING')
    AddTextComponentScaleform(text)
    EndTextCommandScaleformString()
end

local function CreateInstuctionScaleform(scaleform)
    scaleform = RequestScaleformMovie(scaleform)
    while not HasScaleformMovieLoaded(scaleform) do
        Wait(0)
    end
    PushScaleformMovieFunction(scaleform, 'CLEAR_ALL')
    PopScaleformMovieFunctionVoid()

    PushScaleformMovieFunction(scaleform, 'SET_CLEAR_SPACE')
    PushScaleformMovieFunctionParameterInt(200)
    PopScaleformMovieFunctionVoid()

    PushScaleformMovieFunction(scaleform, 'SET_DATA_SLOT')
    PushScaleformMovieFunctionParameterInt(1)
    InstructionButton(GetControlInstructionalButton(1, 194, true))
    InstructionButtonMessage(Lang:t('info.close_camera'))
    PopScaleformMovieFunctionVoid()

    PushScaleformMovieFunction(scaleform, 'DRAW_INSTRUCTIONAL_BUTTONS')
    PopScaleformMovieFunctionVoid()

    PushScaleformMovieFunction(scaleform, 'SET_BACKGROUND_COLOUR')
    PushScaleformMovieFunctionParameterInt(0)
    PushScaleformMovieFunctionParameterInt(0)
    PushScaleformMovieFunctionParameterInt(0)
    PushScaleformMovieFunctionParameterInt(80)
    PopScaleformMovieFunctionVoid()

    return scaleform
end

-- Central entry point so exports can call one function
local function ActivateCamera(cameraId)
    TriggerEvent('jb_cctv:client:ActiveCamera', cameraId or 0)
end

-- Safe shallow copy to prevent accidental external mutation
local function shallowClone(tbl)
    local t = {}
    for k, v in pairs(tbl) do
        t[k] = v
    end
    return t
end

local function GetCamerasCopy()
    return shallowClone(Config.SecurityCameras.cameras)
end

-- Robust array check (fallback if table.type is unavailable)
local function isArray(tbl)
    if type(tbl) ~= 'table' then return false end
    local n = 0
    for k, _ in pairs(tbl) do
        if type(k) ~= 'number' then return false end
        n = n + 1
    end
    return n > 0
end

local function SetCameraOnlineInternal(key, isOnline)
    local flag = isOnline and true or false
    if type(key) == 'table' and (isArray(key) or (table.type and table.type(key) == 'array')) then
        for _, v in pairs(key) do
            if Config.SecurityCameras.cameras[v] then
                Config.SecurityCameras.cameras[v].isOnline = flag
            end
        end
    elseif type(key) == 'number' and Config.SecurityCameras.cameras[key] then
        Config.SecurityCameras.cameras[key].isOnline = flag
    end
end

-- ================
-- Events
-- ================
RegisterNetEvent('jb_cctv:client:ActiveCamera', function(cameraId)
    if Config.SecurityCameras.cameras[cameraId] then
        DoScreenFadeOut(250)
        while not IsScreenFadedOut() do Wait(0) end

        -- 🔹 Freeze ped so WASD won’t move the player while rotating the cam
        FreezeEntityPosition(PlayerPedId(), true)

        SendNUIMessage({
            type = 'enablecam',
            label = Config.SecurityCameras.cameras[cameraId].label,
            id = cameraId,
            connected = Config.SecurityCameras.cameras[cameraId].isOnline,
            time = GetCurrentTime(),
        })

        local c = Config.SecurityCameras.cameras[cameraId].coords
        local r = Config.SecurityCameras.cameras[cameraId].r
        SetFocusArea(c.x, c.y, c.z, c.x, c.y, c.z)
        ChangeSecurityCamera(c.x, c.y, c.z, r)
        currentCameraIndex = cameraId

        DoScreenFadeIn(250)

    elseif cameraId == 0 then
        DoScreenFadeOut(250)
        while not IsScreenFadedOut() do Wait(0) end

        CloseSecurityCamera() -- 🔸 this already unfreezes ped in your function
        SendNUIMessage({ type = 'disablecam' })

        DoScreenFadeIn(250)
    else
        QBCore.Functions.Notify(Lang:t('error.no_camera'), 'error')
    end
end)

RegisterNetEvent('jb_cctv:client:DisableAllCameras', function()
    for k, _ in pairs(Config.SecurityCameras.cameras) do
        Config.SecurityCameras.cameras[k].isOnline = false
    end
end)

RegisterNetEvent('jb_cctv:client:EnableAllCameras', function()
    for k, _ in pairs(Config.SecurityCameras.cameras) do
        Config.SecurityCameras.cameras[k].isOnline = true
    end
end)

RegisterNetEvent('jb_cctv:client:SetCamera', function(key, isOnline)
    if type(key) == 'table' and ((table.type and table.type(key) == 'array') or isArray(key)) then
        for _, v in pairs(key) do
            if Config.SecurityCameras.cameras[v] then
                Config.SecurityCameras.cameras[v].isOnline = isOnline
            end
        end
    elseif type(key) == 'number' and Config.SecurityCameras.cameras[key] then
        Config.SecurityCameras.cameras[key].isOnline = isOnline
    else
        error('jb_cctv:client:SetCamera did not receive the right type of key\nreceived type: ' .. type(key) .. '\nreceived value: ' .. tostring(key))
    end
end)

-- ================
-- Threads
-- ================
CreateThread(function()
    while true do
        local sleep = 2000
        if createdCamera ~= 0 then
            sleep = 5
            local instructions = CreateInstuctionScaleform('instructional_buttons')
            DrawScaleformMovieFullscreen(instructions, 255, 255, 255, 255, 0)
            SetTimecycleModifier('scanline_cam_cheap')
            SetTimecycleModifierStrength(1.0)

            if Config.SecurityCameras.hideradar then
                DisplayRadar(false)
            end

            -- CLOSE CAMERAS (Backspace / 177)
            if IsControlJustPressed(1, 177) then
                DoScreenFadeOut(250)
                while not IsScreenFadedOut() do
                    Wait(0)
                end
                CloseSecurityCamera()
                SendNUIMessage({ type = 'disablecam' })
                DoScreenFadeIn(250)
            end

            -- CAMERA ROTATION CONTROLS
if Config.SecurityCameras.cameras[currentCameraIndex]
and Config.SecurityCameras.cameras[currentCameraIndex].canRotate then
    local getCameraRot = GetCamRot(createdCamera, 2)

    -- ROTATE UP (↑ 172)
    if IsControlPressed(0, 172) then
        if getCameraRot.x <= 0.0 then
            SetCamRot(createdCamera, getCameraRot.x + 0.7, 0.0, getCameraRot.z, 2)
        end
    end

    -- ROTATE DOWN (↓ 173)
    if IsControlPressed(0, 173) then
        if getCameraRot.x >= -50.0 then
            SetCamRot(createdCamera, getCameraRot.x - 0.7, 0.0, getCameraRot.z, 2)
        end
    end

    -- ROTATE LEFT (← 174)
    if IsControlPressed(0, 174) then
        SetCamRot(createdCamera, getCameraRot.x, 0.0, getCameraRot.z + 0.7, 2)
    end

    -- ROTATE RIGHT (→ 175)
    if IsControlPressed(0, 175) then
        SetCamRot(createdCamera, getCameraRot.x, 0.0, getCameraRot.z - 0.7, 2)
    end
end
        end
        Wait(sleep)
    end
end)

-- =========================
-- Exported API (define globals; list them in fxmanifest `exports { ... }`)
-- =========================

-- Open a camera by id. Pass 0 (or nil) to close.
function ViewCamera(cameraId)
    ActivateCamera(tonumber(cameraId) or 0)
end

-- Close the current camera (same as ViewCamera(0))
function CloseCamera()
    ActivateCamera(0)
end

-- Returns a copy of the cameras table for read-only usage
function GetCameras()
    return GetCamerasCopy()
end

-- Toggle one camera id or a list {id1,id2,...}
function SetCameraOnline(key, isOnline)
    SetCameraOnlineInternal(key, isOnline)
end

-- Enable/disable all cameras at once
function SetAllCamerasOnline(isOnline)
    local flag = isOnline and true or false
    for k in pairs(Config.SecurityCameras.cameras) do
        Config.SecurityCameras.cameras[k].isOnline = flag
    end
end

-- =========================
-- (Optional) Simple test commands
-- =========================
RegisterCommand('cam', function(_, args)
    local id = tonumber(args[1] or '0') or 0
    ViewCamera(id)
end, false)

RegisterCommand('camoff', function()
    CloseCamera()
end, false)
