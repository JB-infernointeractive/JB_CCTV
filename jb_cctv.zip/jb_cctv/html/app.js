const wrap   = document.getElementById('wrap');
const label  = document.getElementById('label');
const camid  = document.getElementById('camid');
const status = document.getElementById('status');
const timeEl = document.getElementById('time');
const dot    = document.getElementById('dot');

let clockTimer = null;

// Update TIME every 1s while overlay is visible (client also sends a starting time)
function startClock(seedTime) {
  stopClock();
  if (seedTime) timeEl.textContent = seedTime;
  clockTimer = setInterval(() => {
    // We don’t know server time offset; just tick locally
    const t = timeEl.textContent.split(':');
    if (t.length !== 2) return;
    let h = parseInt(t[0], 10);
    let m = parseInt(t[1], 10) + 1;
    if (m >= 60) { m = 0; h = (h + 1) % 24; }
    timeEl.textContent = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
  }, 1000);
}

function stopClock() {
  if (clockTimer) clearInterval(clockTimer);
  clockTimer = null;
}

function showOverlay(data) {
  label.textContent = data.label || 'CAM';
  camid.textContent = data.id ?? '-';
  const online = !!data.connected;
  status.textContent = online ? 'ONLINE' : 'OFFLINE';
  dot.classList.remove('on', 'off');
  dot.classList.add(online ? 'on' : 'off');
  timeEl.textContent = data.time || '--:--';
  startClock(data.time);
  wrap.classList.remove('hidden');
}

function hideOverlay() {
  stopClock();
  wrap.classList.add('hidden');
}

window.addEventListener('message', (e) => {
  const data = e.data || {};
  if (data.type === 'enablecam') {
    showOverlay(data);
  } else if (data.type === 'disablecam') {
    hideOverlay();
  }
});
