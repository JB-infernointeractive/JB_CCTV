-- locales/en.lua
local Translations = {
    info = {
        close_camera = 'Close Camera',
    },
    error = {
        no_camera = 'No camera found with that ID',
    }
}

Lang = Locale:new({
    phrases = Translations,
    warnOnMissing = true,
    fallbackLang = 'en'
})
